query = 'TTIP'
expandedAcronym = /Transatlantic Trade/
